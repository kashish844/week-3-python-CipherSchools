# exercisse decorator
import time

t1=time.time()
print("this is line one")
x=5
if x==5:
    print('x is equal to 5')
print('this is line two')
print('this is line two')
print('this is line two')
print('this is line two')
print('this is line two')
print('this is line two')
print('this is line two')
print('this is line two')
print('this is line two')
print('this is line two')
print('this is line two')
print('this is line two')
print('this is line two')
print('this is line two')
print('this is line two')
t2=time.time()
print(t2-t1)
