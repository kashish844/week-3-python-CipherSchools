# set data type
# unordered collection of unique items

s={1,2,3}

s={1,1.0,2.3, 'string'} #cannot store list and dictionary in it

# print(s[1])
# l=[1,2,3,4,5,5,5,6,7,7,8]
# remove duplicate
# s2=list(set(l))
# print(s2)
# s.add(4)
# s.add(5)
# s.add(4)
# s.remove(3)
# s.discard(5)
# s1 = s.copy()
# print(s1)
print(s)
